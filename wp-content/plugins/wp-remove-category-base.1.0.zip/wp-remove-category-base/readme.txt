=== WP Remove Category Base ===
Contributors: ezraverheijen
Tags: category base, category prefix, category slug
Requires at least: 3.5
Tested up to: 4.2
Stable tag: 1.0
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Removes the category base slug from the category archive permalinks (URL's).

== Description ==

This is actually the deprecated code from WordPress SEO, with some small improvements added to it.

== Installation ==

1. Upload the `wp-remove-category-base` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. No need to configure, it just works!

== Frequently Asked Questions ==

= Is this really the same functionality as the deprecated functionality from the WordPress SEO plugin by Yoast? =

Yes. With a few small improvements.

= Is it legal to copy and use Joost's code like that? =

Yes.

== Changelog ==

= 1.0 =
* Initial release
